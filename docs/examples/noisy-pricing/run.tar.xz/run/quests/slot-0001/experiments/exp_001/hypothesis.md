# Research action

Specify a hypothesis test, rival test, replication, measurement, data acquisition, or stop decision.
