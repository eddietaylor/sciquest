# Registered experiment exp_001

## Evidence
Metrics computed by the supervisor from registered truth and prediction artifacts.

- regret_nonnegative_sanity_only: supported

## Metrics
- regret (primary): 130.3825352746989
- policy_value (diagnostic): 4487.767430830212
- mean_demand_rmse (diagnostic): 6.49568977662859
- individual_demand_rmse (diagnostic): 9.979261522842322

## Constraints
No separate constraint requirements registered.

## Undefined metrics
None.

## Inquiry policy evidence
```json
{
  "contract": {
    "enforced_plan_contracts": [],
    "guidance_only_methods": [
      "standard_empirical"
    ],
    "inactive_plan_extensions": [],
    "phase_governance": {
      "evidence_evaluation": "standard_empirical",
      "experiment_design": "standard_empirical",
      "hypothesis_generation": "standard_empirical",
      "long_term_tracking": "standard_empirical",
      "problem_framing": "standard_empirical",
      "stress_testing": "standard_empirical"
    },
    "requirements": {},
    "scope": "Registered planning constraints and numerical evidence updates; not a guarantee of philosophical fidelity or test severity",
    "version": 2
  },
  "observed_prediction_outcomes": {
    "regret_nonnegative_sanity_only": "supported"
  }
}
```

## Scope
Registered decision rules; not automatic causal identification or statistical error control
Decision metrics use owner-supplied expected intervention values on the registered finite action grid. Scientific understanding and causal identification require separate evidence.

## Speculation
No broader causal or real-world conclusion follows automatically.
